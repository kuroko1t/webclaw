true&&(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
}());

const logContainer = document.getElementById("logContainer");
const emptyState = document.getElementById("emptyState");
const statusEl = document.getElementById("status");
const clearBtn = document.getElementById("clearBtn");
let entries = [];
chrome.runtime.onMessage.addListener((message) => {
  if (message.channel === "webclaw-sidepanel-update" && message.type === "activity") {
    addLogEntry(message.data);
  }
});
clearBtn.addEventListener("click", () => {
  entries = [];
  logContainer.innerHTML = "";
  emptyState.style.display = "flex";
  logContainer.appendChild(emptyState);
});
function addLogEntry(entry) {
  entries.push(entry);
  if (emptyState.parentElement) {
    emptyState.style.display = "none";
  }
  statusEl.textContent = "Active";
  statusEl.classList.add("connected");
  const el = document.createElement("div");
  el.className = "log-entry";
  const timeSpan = document.createElement("span");
  timeSpan.className = "timestamp";
  timeSpan.textContent = new Date(entry.timestamp).toLocaleTimeString();
  el.appendChild(timeSpan);
  const actionSpan = document.createElement("span");
  actionSpan.className = "action-name";
  actionSpan.textContent = entry.action;
  el.appendChild(actionSpan);
  const detailKeys = Object.keys(entry).filter(
    (k) => !["action", "timestamp", "url"].includes(k)
  );
  if (detailKeys.length > 0) {
    const detailsDiv = document.createElement("div");
    detailsDiv.className = "details";
    detailsDiv.textContent = detailKeys.map((k) => `${k}: ${JSON.stringify(entry[k])}`).join(" | ");
    el.appendChild(detailsDiv);
  }
  logContainer.appendChild(el);
  el.scrollIntoView({ behavior: "smooth" });
}
