import { W as WEBSOCKET_PORT_RANGE_SIZE, a as WEBSOCKET_DEFAULT_PORT, K as KEEPALIVE_INTERVAL_MS } from '../chunks/constants-BsnG5bn6.js';

function createResponse(requestId, method, payload = {}) {
  return {
    id: requestId,
    type: "response",
    method,
    payload,
    timestamp: Date.now()
  };
}
function createError(requestId, method, code, message, details) {
  return {
    id: requestId,
    type: "error",
    method,
    payload: { code, message, details },
    timestamp: Date.now()
  };
}

const RECONNECT_INTERVAL_MS = 3e3;
class WebSocketBridge {
  ws = null;
  url;
  router;
  reconnectTimer = null;
  disposed = false;
  hasConnectedOnce = false;
  constructor(url, router) {
    this.url = url;
    this.router = router;
    this.connect();
  }
  connect() {
    if (this.disposed) return;
    try {
      this.ws = new WebSocket(this.url);
      this.ws.addEventListener("open", () => {
        this.hasConnectedOnce = true;
        console.log(`[WebClaw Bridge] Connected to MCP server (${this.url})`);
      });
      this.ws.addEventListener("message", (event) => {
        this.handleMessage(event.data);
      });
      this.ws.addEventListener("close", () => {
        if (this.hasConnectedOnce) {
          console.log(`[WebClaw Bridge] Disconnected from MCP server (${this.url})`);
        }
        this.ws = null;
        this.scheduleReconnect();
      });
      this.ws.addEventListener("error", () => {
      });
    } catch {
      this.ws = null;
      this.scheduleReconnect();
    }
  }
  scheduleReconnect() {
    if (this.disposed || this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, RECONNECT_INTERVAL_MS);
  }
  async handleMessage(data) {
    try {
      const message = typeof data === "string" ? JSON.parse(data) : null;
      if (!message) return;
      const request = message;
      if (!request.id || !request.method) {
        console.error("[WebClaw Bridge] Invalid message:", message);
        return;
      }
      console.log(`[WebClaw Bridge] Request: ${request.method}`, request.id);
      this.send({
        id: request.id,
        type: "ack",
        method: request.method,
        payload: {},
        timestamp: Date.now()
      });
      const response = await this.router.handleBridgeRequest(request);
      this.send(response);
    } catch (err) {
      console.error("[WebClaw Bridge] Error handling message:", err);
      try {
        const msg = typeof data === "string" ? JSON.parse(data) : {};
        this.send({
          id: msg.id ?? "unknown",
          type: "error",
          method: msg.method ?? "unknown",
          payload: {
            code: "INTERNAL_ERROR",
            message: err instanceof Error ? err.message : String(err)
          },
          timestamp: Date.now()
        });
      } catch {
      }
    }
  }
  send(message) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.warn("[WebClaw Bridge] Cannot send, not connected");
      return;
    }
    try {
      this.ws.send(JSON.stringify(message));
    } catch (err) {
      console.error("[WebClaw Bridge] Send error:", err);
    }
  }
  isConnected() {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }
  disconnect() {
    this.disposed = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}

class TabManager {
  tabs = /* @__PURE__ */ new Map();
  /** Get the active tab ID, or a specific tab */
  async getTargetTabId(requestedTabId) {
    if (requestedTabId !== void 0) {
      return requestedTabId;
    }
    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    if (!tab?.id) {
      throw new Error("No active tab found");
    }
    return tab.id;
  }
  /** Send a message to a content script */
  async sendToContentScript(tabId, message) {
    await this.ensureContentScript(tabId);
    return chrome.tabs.sendMessage(tabId, {
      channel: "webclaw-action",
      ...message
    });
  }
  /** Execute a script in the MAIN world of a tab */
  async executeInMainWorld(tabId, func, args = []) {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func,
      args
    });
    return results[0]?.result;
  }
  /** Ensure content script is injected into a tab */
  async ensureContentScript(tabId) {
    const state = this.tabs.get(tabId);
    if (state?.ready) return;
    try {
      await chrome.tabs.sendMessage(tabId, {
        channel: "webclaw-action",
        action: "ping"
      });
    } catch {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["src/content/content-script.js"]
      });
    }
    this.tabs.set(tabId, { id: tabId, ready: true });
  }
  /** Store the latest snapshot ID for a tab */
  setSnapshotId(tabId, snapshotId) {
    const state = this.tabs.get(tabId) ?? { id: tabId, ready: true };
    state.snapshotId = snapshotId;
    this.tabs.set(tabId, state);
  }
  /** Get the latest snapshot ID for a tab */
  getSnapshotId(tabId) {
    return this.tabs.get(tabId)?.snapshotId;
  }
  /** Mark tab as ready */
  onTabReady(tabId) {
    const state = this.tabs.get(tabId);
    if (state) {
      state.ready = true;
    }
  }
  /** Clean up when tab is removed */
  onTabRemoved(tabId) {
    this.tabs.delete(tabId);
  }
}

const TAB_LOAD_TIMEOUT_MS = 3e4;
class MessageRouter {
  constructor(tabManager) {
    this.tabManager = tabManager;
  }
  /** Handle a bridge request and return a response */
  async handleBridgeRequest(request) {
    const { id, method, payload } = request;
    try {
      let result;
      switch (method) {
        case "navigate":
          result = await this.handleNavigate(payload);
          break;
        case "snapshot":
          result = await this.handleSnapshot(payload);
          break;
        case "click":
          result = await this.handleClick(payload);
          break;
        case "hover":
          result = await this.handleHover(payload);
          break;
        case "typeText":
          result = await this.handleTypeText(payload);
          break;
        case "selectOption":
          result = await this.handleSelectOption(payload);
          break;
        case "listWebMCPTools":
          result = await this.handleListWebMCPTools(
            payload
          );
          break;
        case "invokeWebMCPTool":
          result = await this.handleInvokeWebMCPTool(
            payload
          );
          break;
        case "screenshot":
          result = await this.handleScreenshot(payload);
          break;
        case "newTab":
          result = await this.handleNewTab(payload);
          break;
        case "listTabs":
          result = await this.handleListTabs();
          break;
        case "switchTab":
          result = await this.handleSwitchTab(payload);
          break;
        case "closeTab":
          result = await this.handleCloseTab(payload);
          break;
        case "goBack":
          result = await this.handleGoBack(payload);
          break;
        case "goForward":
          result = await this.handleGoForward(payload);
          break;
        case "reload":
          result = await this.handleReload(payload);
          break;
        case "waitForNavigation":
          result = await this.handleWaitForNavigation(
            payload
          );
          break;
        case "scrollPage":
          result = await this.handleScrollPage(payload);
          break;
        case "ping":
          result = { pong: true, timestamp: Date.now() };
          break;
        default:
          return createError(id, method, "UNKNOWN_METHOD", `Unknown method: ${method}`);
      }
      return createResponse(id, method, result);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      let code = "HANDLER_ERROR";
      if (message.includes("not found") || message.includes("No tab with id")) {
        code = "TAB_NOT_FOUND";
      } else if (message.includes("No active tab") || message.includes("No tab")) {
        code = "NO_ACTIVE_TAB";
      } else if (message.includes("Stale snapshot")) {
        code = "STALE_SNAPSHOT";
      } else if (message.includes("Cannot find a next page")) {
        code = "NAVIGATION_TIMEOUT";
      }
      return createError(id, method, code, message);
    }
  }
  /** Handle content script messages */
  handleContentScriptMessage(message, sender, sendResponse) {
    const tabId = sender.tab?.id;
    if (!tabId) {
      sendResponse({ error: "No tab ID" });
      return;
    }
    switch (message.action) {
      case "log":
        chrome.runtime.sendMessage({
          channel: "webclaw-sidepanel-update",
          type: "activity",
          data: message.data,
          tabId
        }).catch(() => {
        });
        sendResponse({ ok: true });
        break;
      case "getTabId":
        sendResponse(tabId);
        break;
      default:
        sendResponse({ error: `Unknown content action: ${message.action}` });
    }
  }
  // --- Handler implementations ---
  /** Wait for a tab to finish loading */
  waitForTabLoad(tabId, timeoutMs = TAB_LOAD_TIMEOUT_MS) {
    return new Promise((resolve) => {
      const listener = (updatedTabId, changeInfo) => {
        if (updatedTabId === tabId && changeInfo.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
      setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }, timeoutMs);
    });
  }
  async handleNavigate(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    await chrome.tabs.update(tabId, { url: params.url });
    await this.waitForTabLoad(tabId);
    const tab = await chrome.tabs.get(tabId);
    return { url: tab.url, title: tab.title, tabId };
  }
  async handleSnapshot(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    const result = await this.tabManager.sendToContentScript(tabId, {
      action: "snapshot",
      maxTokens: params.maxTokens
    });
    if (result && typeof result === "object" && "snapshotId" in result) {
      this.tabManager.setSnapshotId(tabId, result.snapshotId);
    }
    return result;
  }
  async handleClick(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    this.validateSnapshotId(tabId, params.snapshotId);
    return this.tabManager.sendToContentScript(tabId, {
      action: "click",
      ref: params.ref
    });
  }
  async handleHover(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    this.validateSnapshotId(tabId, params.snapshotId);
    return this.tabManager.sendToContentScript(tabId, {
      action: "hover",
      ref: params.ref
    });
  }
  async handleTypeText(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    this.validateSnapshotId(tabId, params.snapshotId);
    return this.tabManager.sendToContentScript(tabId, {
      action: "typeText",
      ref: params.ref,
      text: params.text,
      clearFirst: params.clearFirst
    });
  }
  async handleSelectOption(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    this.validateSnapshotId(tabId, params.snapshotId);
    return this.tabManager.sendToContentScript(tabId, {
      action: "selectOption",
      ref: params.ref,
      value: params.value
    });
  }
  async handleListWebMCPTools(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    return this.tabManager.sendToContentScript(tabId, {
      action: "listWebMCPTools"
    });
  }
  async handleInvokeWebMCPTool(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    return this.tabManager.sendToContentScript(tabId, {
      action: "invokeWebMCPTool",
      toolName: params.toolName,
      args: params.args
    });
  }
  async handleScreenshot(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    const dataUrl = await chrome.tabs.captureVisibleTab(void 0, {
      format: "png"
    });
    return { dataUrl, tabId };
  }
  async handleNewTab(params) {
    const createProps = {};
    if (params.url) {
      createProps.url = params.url;
    }
    const tab = await chrome.tabs.create(createProps);
    if (params.url && tab.id) {
      await this.waitForTabLoad(tab.id);
    }
    const updatedTab = tab.id ? await chrome.tabs.get(tab.id) : tab;
    return {
      tabId: updatedTab.id,
      url: updatedTab.url,
      title: updatedTab.title
    };
  }
  async handleListTabs() {
    const tabs = await chrome.tabs.query({});
    return {
      tabs: tabs.map((tab) => ({
        tabId: tab.id,
        url: tab.url,
        title: tab.title,
        active: tab.active
      }))
    };
  }
  async handleSwitchTab(params) {
    await chrome.tabs.update(params.tabId, { active: true });
    const tab = await chrome.tabs.get(params.tabId);
    if (tab.windowId !== void 0) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
    return {
      tabId: tab.id,
      url: tab.url,
      title: tab.title
    };
  }
  async handleCloseTab(params) {
    await chrome.tabs.remove(params.tabId);
    return { closed: true, tabId: params.tabId };
  }
  async handleGoBack(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    const [result] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => ({ length: history.length })
    });
    if (result?.result?.length <= 1) {
      throw new Error("No previous page in navigation history");
    }
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        history.back();
      }
    });
    await new Promise((r) => setTimeout(r, 100));
    await this.waitForTabLoad(tabId, 1e4);
    const tab = await chrome.tabs.get(tabId);
    return { url: tab.url, title: tab.title, tabId };
  }
  async handleGoForward(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        history.forward();
      }
    });
    await new Promise((r) => setTimeout(r, 100));
    await this.waitForTabLoad(tabId, 1e4);
    const tab = await chrome.tabs.get(tabId);
    return { url: tab.url, title: tab.title, tabId };
  }
  async handleReload(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    await chrome.tabs.reload(tabId, {
      bypassCache: params.bypassCache ?? false
    });
    await this.waitForTabLoad(tabId);
    const tab = await chrome.tabs.get(tabId);
    return { url: tab.url, title: tab.title, tabId };
  }
  async handleWaitForNavigation(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    const timeoutMs = params.timeoutMs ?? TAB_LOAD_TIMEOUT_MS;
    try {
      const currentTab = await chrome.tabs.get(tabId);
      if (currentTab.status === "complete") {
        return { url: currentTab.url, title: currentTab.title, tabId };
      }
    } catch {
    }
    await this.waitForTabLoad(tabId, timeoutMs);
    const tab = await chrome.tabs.get(tabId);
    return { url: tab.url, title: tab.title, tabId };
  }
  async handleScrollPage(params) {
    const tabId = await this.tabManager.getTargetTabId(params.tabId);
    if (params.ref) {
      if (params.snapshotId) {
        this.validateSnapshotId(tabId, params.snapshotId);
      }
      return this.tabManager.sendToContentScript(tabId, {
        action: "scrollToElement",
        ref: params.ref
      });
    }
    return this.tabManager.sendToContentScript(tabId, {
      action: "scrollPage",
      direction: params.direction ?? "down",
      amount: params.amount
    });
  }
  /** Validate that the snapshot ID matches the current tab snapshot */
  validateSnapshotId(tabId, snapshotId) {
    const currentSnapshotId = this.tabManager.getSnapshotId(tabId);
    if (currentSnapshotId && currentSnapshotId !== snapshotId) {
      throw new Error(
        `Stale snapshot: expected ${currentSnapshotId}, got ${snapshotId}. Take a new snapshot first.`
      );
    }
  }
}

const tabManager = new TabManager();
const messageRouter = new MessageRouter(tabManager);
const wsBridges = [];
for (let i = 0; i < WEBSOCKET_PORT_RANGE_SIZE; i++) {
  wsBridges.push(
    new WebSocketBridge(
      `ws://127.0.0.1:${WEBSOCKET_DEFAULT_PORT + i}`,
      messageRouter
    )
  );
}
chrome.alarms.create("webclaw-keepalive", {
  periodInMinutes: KEEPALIVE_INTERVAL_MS / 6e4
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "webclaw-keepalive") {
    void chrome.storage.session.get("keepalive");
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.channel === "webclaw-content") {
    messageRouter.handleContentScriptMessage(message, sender, sendResponse);
    return true;
  }
  if (message.channel === "webclaw-sidepanel") {
    broadcastToSidePanel(message);
    sendResponse({ ok: true });
    return false;
  }
});
function broadcastToSidePanel(message) {
  chrome.runtime.sendMessage({ channel: "webclaw-sidepanel-update", ...message }).catch(() => {
  });
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "complete") {
    tabManager.onTabReady(tabId);
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  tabManager.onTabRemoved(tabId);
});
chrome.sidePanel?.setOptions({
  enabled: true
}).catch(() => {
});
chrome.action?.onClicked?.addListener((tab) => {
  if (tab.id) {
    chrome.sidePanel?.open({ tabId: tab.id }).catch(console.error);
  }
});
console.log("[WebClaw] Service Worker started");
